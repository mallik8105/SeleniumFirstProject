package com.operation1;

public interface Setup {
	
	
	String CHROME_KEY = "webdriver.chrome.driver";
	
	String CHROME_PATH = "C:\\Users\\Arjun reddy kallem\\Downloads\\chromedriver_win32\\chromedriver.exe";
			
}